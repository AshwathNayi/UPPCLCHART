package bisag.gatishakti.Repository2;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.*;

import bisag.gatishakti.Entities.db2.UppclPole_Energy;

public interface UppclPole_Energy_Repo extends JpaRepository<UppclPole_Energy, Integer> {

	@Query(value="select distinct circle,(count(feedername11kv)) as feedereleven,(count(feedername33kv)) as feederthirtythree,(count(feeder11kv)) as elevenkv from feederline_sarvey_uppclmobapp group by circle order by circle",nativeQuery=true)
	List<Map<String,Object>> getlistofcircle();
}
