package bisag.gatishakti.controller.Education;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.locationtech.jts.io.WKTReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import com.google.gson.Gson;

import bisag.gatishakti.Entities.Education.EduEntity;
import bisag.gatishakti.Entities.db2.Customhiringcenter;
import bisag.gatishakti.Entities.db2.FertilizerData;
import bisag.gatishakti.Entities.db2.GovtFarmDataFeeder;
import bisag.gatishakti.Entities.db2.IntegratedPestManagementLabs;
import bisag.gatishakti.Entities.db2.KhetTalaabDataFeeder;
import bisag.gatishakti.Entities.db2.PesticidesData;
import bisag.gatishakti.Entities.db2.Report_Farm_Machinary_Bank;
import bisag.gatishakti.Entities.db2.SeedDataFeeder;
import bisag.gatishakti.Entities.db2.SoilTestLabData;
import bisag.gatishakti.Entities.db2.SolarPumpDataFeeder;
import bisag.gatishakti.Entities.db2.UniversityData;
import bisag.gatishakti.Entities.db2.UppclPole_Energy;
import bisag.gatishakti.Entities.db2.krishivigyankendra;
import bisag.gatishakti.Entities.model.AssetsMapping;

import bisag.gatishakti.Entities.model.Users;
import bisag.gatishakti.Repository.AssetsMappingRepository;
import bisag.gatishakti.Repository.EducationRepo;
import bisag.gatishakti.Repository.UserDAO;
import bisag.gatishakti.controller.LoginController;
import bisag.gatishakti.Repository2.CustomhiringRepo;
import bisag.gatishakti.Repository2.krishvigyankendraRepo;
import bisag.gatishakti.Repository2.FertilizerRepo;
import bisag.gatishakti.Repository2.PesticidesRepo;
import bisag.gatishakti.Repository2.Report_Farm_Machinary_Bankrepo;
import bisag.gatishakti.Repository2.SoilTestLabDataRepo;
import bisag.gatishakti.Repository2.UniversityDataRepo;
import bisag.gatishakti.Repository2.UppclPole_Energy_Repo;
import bisag.gatishakti.Repository2.KhetTalaabDataFeederRepo;
import bisag.gatishakti.Repository2.SeedDataFeederRepo;
import bisag.gatishakti.Repository2.GovtFarmDataFeederRepo;
import bisag.gatishakti.Repository2.IntegratedPestManagementLabsRepo;
import bisag.gatishakti.Repository2.SolarPumpDataFeederRepo;
@Controller
@SpringBootApplication
@ComponentScan(basePackageClasses = LoginController.class)
public class EducationController {
	@Autowired
	private Report_Farm_Machinary_Bankrepo reportfarmmachinbank;
	@Autowired
	private krishvigyankendraRepo krishivrepo;
	@Autowired
	private CustomhiringRepo customhirerepo;
	@Autowired
	private KhetTalaabDataFeederRepo ktrepo;
	@Autowired
	private SeedDataFeederRepo srrepo;
	@Autowired
	private FertilizerRepo fp;
	@Autowired
	PesticidesRepo pp;
	@Autowired
	private UniversityDataRepo universityrepo;
	@Autowired
	private SoilTestLabDataRepo soilrepo;
	@Autowired
	GovtFarmDataFeederRepo govtrepo;
	@Autowired
	SolarPumpDataFeederRepo solarrepo;
	@Autowired
	IntegratedPestManagementLabsRepo pestrepo;
	@Autowired
	EducationRepo edurepo;
	@Autowired
	JdbcTemplate template;
	@Autowired
	private UserDAO user;
	@Qualifier("jdbcTemplate2")
	@Autowired
    private JdbcTemplate template2;
	@Autowired 	
	private  UppclPole_Energy_Repo uppclpolerepo;
	
	@GetMapping("/SecEduRptOne")
	public String SecEduRptOne(Model model, Principal principal)
	{
		List<Map<String, Object>> districtna12 = template2.queryForList("select distinct username from pahuch_school_mobile_app_up_form_one order by username");
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "SecondaryEducation/SecEduReportOne";
	}
	@GetMapping("/SecEduRpttwo")
	public String SecEduRpttwo(Model model, Principal principal)
	{
		List<Map<String, Object>> districtna12 = template2.queryForList("select distinct boyenrollmentnumber from pahuch_school_mobile_app_up_form_two order by boyenrollmentnumber");
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "SecondaryEducation/SecEduReportTwo";
	}
	
	///Rakesh Education Dashboard --12-04-2023
	@RequestMapping("/EduDashboard")
	public String EduDashboard(Model model)
	{
		List<Map<String, Object>> list = template.queryForList("select distinct schoolname from education_secondry order by schoolname ");
		model.addAttribute("schoolname_cmd", list);
		
		List<Map<String, Object>> sch_type = template.queryForList("select distinct sch_type from education_secondry order by sch_type ");
		model.addAttribute("sch_type_cmd", sch_type);
		
		List<Map<String, Object>> dist = template.queryForList("select distinct districtna  from education_secondry  order by districtna  ");
		model.addAttribute("district_cmd", dist);
		//List<Map<String, Object>> list = template2.queryForList("select distinct schoolname from pahuch_school_mobile_app_up_form_one group by schoolname order by schoolname ");
		//model.addAttribute("schoolname_cmd", list);
		
//		List<Map<String, Object>> department = template2.queryForList("select  dept_id,department_name from up_department order by up_department");
		
				List<Map<String, Object>> total_anganwadi_yes = template2.queryForList("select * from pahuch_school_mobile_app_up_form_one where fiftytwoyesornoanganwadicenteroperated ='हाँ'");
				model.addAttribute("total_anganwadi_yes", total_anganwadi_yes.size());
		
				List<Map<String, Object>> total_anganwadi_no = template2.queryForList("select * from pahuch_school_mobile_app_up_form_one where fiftytwoyesornoanganwadicenteroperated ='नहीं'");
				model.addAttribute("total_anganwadi_no", total_anganwadi_no.size());
				
				List<Map<String, Object>> total_repairwork_yes = template2.queryForList("select * from pahuch_school_mobile_app_up_form_one where thirtyoneyesornoanyrepairwork ='हाँ'");
				model.addAttribute("total_repairwork_yes", total_repairwork_yes.size());
		
				List<Map<String, Object>> total_repairwork_no = template2.queryForList("select * from pahuch_school_mobile_app_up_form_one where thirtyoneyesornoanyrepairwork ='नहीं'");
				model.addAttribute("total_repairwork_no", total_repairwork_no.size());
				
				List<Map<String, Object>> BenchesAvailable_yes = template2.queryForList("select * from pahuch_school_mobile_app_up_form_one where sixtenyesornobenchesavailableforallchildrenofall ='हाँ'");
				model.addAttribute("BenchesAvailable_yes", BenchesAvailable_yes.size());
				
				List<Map<String, Object>> BenchesAvailable_no = template2.queryForList("select * from pahuch_school_mobile_app_up_form_one where sixtenyesornobenchesavailableforallchildrenofall ='नहीं'");
				model.addAttribute("BenchesAvailable_no", BenchesAvailable_no.size());


				List<Map<String, Object>> Toilet_yes = template2.queryForList("select * from pahuch_school_mobile_app_up_form_one where threeyesornoboystoiletavalible ='नहीं'");
				model.addAttribute("Toilet_yes", Toilet_yes.size());
				
				List<Map<String, Object>> Toilet_no = template2.queryForList("select * from pahuch_school_mobile_app_up_form_one where threeyesornoboystoiletavalible ='हाँ'");
				model.addAttribute("Toilet_no", Toilet_no.size());

				List<Map<String, Object>> DrinkingWater_yes = template2.queryForList("select * from pahuch_school_mobile_app_up_form_one where oneyesornocleandrinkingwater ='नहीं'");
				model.addAttribute("DrinkingWater_yes", DrinkingWater_yes.size());
				
				List<Map<String, Object>> DrinkingWater_no = template2.queryForList("select * from pahuch_school_mobile_app_up_form_one where oneyesornocleandrinkingwater ='हाँ'");
				model.addAttribute("DrinkingWater_no", DrinkingWater_no.size());

				List<Map<String, Object>> tot_sec_school = template.queryForList("select * from education_secondry where schoolname is not null");
				model.addAttribute("tot_sec_school", tot_sec_school.size());
				
				List<Map<String, Object>> tot_aied = template.queryForList("select * from education_secondry where sch_type  ='AIDED'  ");
				model.addAttribute("tot_aied", tot_aied.size());
				model.addAttribute("tot_aied_all", tot_aied);
				
				
				List<Map<String, Object>> tot_aied_10th = template.queryForList("select * from education_secondry where sch_type  ='AIDED' and sch_level='10th'  ");
				model.addAttribute("tot_aied_10th", tot_aied_10th.size());
				
				List<Map<String, Object>> tot_aied_12th = template.queryForList("select * from education_secondry where sch_type  ='AIDED' and sch_level='12th'  ");
				model.addAttribute("tot_aied_12th", tot_aied_12th.size());
				//Chart
				List<Map<String, Object>> tot_10_12aied = template.queryForList("SELECT education_secondry.districtna,\n" + 
						"    count(education_secondry.sch_level) FILTER (WHERE education_secondry.sch_level::text = '10th'::text) AS aided_10th,\n" + 
						"    count(education_secondry.sch_level) FILTER (WHERE education_secondry.sch_level::text = '12th'::text) AS aided_12th\n" + 
						"    from education_secondry where  sch_type  ='AIDED' group by districtna order by districtna ");
				//model.addAttribute("tot_10_12aied_length", tot_10_12aied.size());
				model.addAttribute("tot_10_12aied", tot_10_12aied);
				
				List<Map<String, Object>> tot_govt = template.queryForList("select * from education_secondry where sch_type  ='GOVT'  ");
				model.addAttribute("tot_govt", tot_govt.size());
				model.addAttribute("tot_govt_all", tot_govt);
				
				List<Map<String, Object>> tot_govt_10th = template.queryForList("select * from education_secondry where sch_type  ='GOVT' and sch_level='10th'  ");
				model.addAttribute("tot_govt_10th", tot_govt_10th.size());
				
				List<Map<String, Object>> tot_govt_12th = template.queryForList("select * from education_secondry where sch_type  ='GOVT' and sch_level='12th'  ");
				model.addAttribute("tot_govt_12th", tot_govt_12th.size());
				
				
				List<Map<String, Object>> tot_unaied = template.queryForList("select * from education_secondry where sch_type  ='UN-AIDED'  ");
				model.addAttribute("tot_unaied", tot_unaied.size());
				model.addAttribute("tot_unaied_all", tot_unaied);
				
				List<Map<String, Object>> tot_unaied_10th = template.queryForList("select * from education_secondry where sch_type  ='UN-AIDED' and sch_level='10th'  ");
				model.addAttribute("tot_unaied_10th", tot_unaied_10th.size());
				
				List<Map<String, Object>> tot_unaied_12th = template.queryForList("select * from education_secondry where sch_type  ='UN-AIDED' and sch_level='12th'  ");
				model.addAttribute("tot_unaied_12th", tot_unaied_12th.size());
				
				List<Map<String, Object>> districtna = template.queryForList("select distinct districtna,count(*) from education_secondry group by districtna order by districtna ");
				model.addAttribute("districtna", districtna);
				
				
				
		return "SecondaryEducation/EduDashboard";
	}
	
	
	@GetMapping("/tot_10_12aied_all")
    @ResponseBody
    public List<Map<String, Object>> tot_10_12aied_all(Model model) {

        String eduuuqq = "SELECT education_secondry.districtna,count(education_secondry.sch_level) FILTER (WHERE education_secondry.sch_level::text = '10th'::text) AS aided_10th,count(education_secondry.sch_level) FILTER (WHERE education_secondry.sch_level::text = '12th'::text) AS aided_12th  from education_secondry where  sch_type  ='AIDED' group by districtna order by districtna ";
        List<Map<String, Object>> eduuu = template.queryForList(eduuuqq);
        return eduuu;

    }

	@GetMapping("/getallcolumnname")
	@ResponseBody
	public List getallcolumnname(String tbl,String col)
	{
		String qf = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '"+tbl+"' and column_name != '"+col+"' ";
		System.out.println("getallcolumnname======="+qf);
		List<Map<String, Object>> list = template.queryForList(qf);
		
		return list;
	}
	
	@GetMapping("/getdataAll")
	@ResponseBody
	public List getdataAll(String q)
	{
		System.out.println("getdataAll======="+q);
		List<Map<String, Object>> list = template.queryForList(q);
		
		return list;
	}
	/////////////

	/////////////
	
	
	@GetMapping("/Report_Mandi")
	public String Report_Mandi(Model model, Principal principal)
	{
		//List<Users> us = user.findByUsername(principal.getName());
		model.addAttribute("username", principal.getName());
		List<Map<String, Object>> districtna12=null;
//		String dist = null;
//		dist = us.get(0).getDistrict();
		if(principal.getName().equals(null))
		{
			districtna12 = template2.queryForList("select distinct type_of_project from mandi_parishad_form_data_mob_app order by type_of_project");	
		}
		else
		{
			districtna12 = template2.queryForList("select distinct type_of_project from mandi_parishad_form_data_mob_app where type_of_project='"+principal.getName()+"' order by type_of_project");
		}
		
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "Agriculture/Report_Mandi";
	}
	
	
	@GetMapping("/Report_Farm_Machinary_Bankrpt")
	public String Report_Farm_Machinary_Bankrpt(Model model, Principal principal)
	{
		//List<Users> us = user.findByUsername(principal.getName());
		model.addAttribute("username", principal.getName());
		List<Map<String, Object>> districtna12=null;
//		String dist = null;
//		dist = us.get(0).getDistrict();
		if(principal.getName().equals(null))
		{
			districtna12 = template2.queryForList("select distinct username from farmmachienerybank_datafeedermobapp order by username");	
		}
		else
		{
			districtna12 = template2.queryForList("select distinct username from farmmachienerybank_datafeedermobapp where username='"+principal.getName()+"' order by username");
		}
		
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "Agriculture/Report_Farm_Machinary_Bank";
	}
	@GetMapping("/Report_Fertilizer")
	public String Report_Fertilizer(Model model, Principal principal)
	{
		List<Map<String, Object>> districtna12 = template2.queryForList("select distinct districtname from fertilizer_datafeedermobapp order by districtname");
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12);
		return "Agriculture/Report_Fertilizer";
	}
	
	@GetMapping("/Report_Seed")
	public String Report_Seed(Model model, Principal principal)
	{
		List<Map<String, Object>> districtna12 = template2.queryForList("select distinct districtname from seed_datafeedermobapp order by districtname");
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "Agriculture/Report_Seed";
	}
	
	@GetMapping("/Report_Pesticides")
	public String Report_Pesticides(Model model, Principal principal)
	{
		List<Map<String, Object>> districtna12 = template2.queryForList("select distinct districtname from pesticides_datafeedermobapp order by districtname");
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "Agriculture/Report_Pesticides";
	}
	
	@GetMapping("/Report_Khet_Talaab")
	public String Report_Khet_Talaab(Model model, Principal principal)
	{
		List<Map<String, Object>> districtna12 = template2.queryForList("select *from khettalaab_datafeedermobapp ");
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "Agriculture/Report_Khet_Talaab";
	}
	 
	@GetMapping("/Report_Solar_Pump")
	public String Report_Solar_Pump(Model model, Principal principal)
	{
		List<Map<String, Object>> districtna12 = template2.queryForList("select distinct districtname from solarpump_datafeedermobapp order by districtname");
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "Agriculture/Report_Solar_Pump";
	}

	
	@GetMapping("/Report_University")
	public String Report_University(Model model, Principal principal)
	{
		List<Map<String, Object>> districtna12 = template2.queryForList("select distinct username from university_datafeedermobapp order by username");
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "Agriculture/Report_University";
	}
	
	@GetMapping("/Report_Krishi_Vigyan_Kendra")
	public String Report_Krishi_Vigyan_Kendra(Model model, Principal principal)
	{
		List<Map<String, Object>> districtna12 = template2.queryForList("select distinct username from krishivigyankendra_datafeedermobapp order by username");
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "Agriculture/Report_Krishi_Vigyan_Kendra";
	}
	
	@GetMapping("/Report_Govt_Farms")
	public String Report_Govt_Farms(Model model, Principal principal)
	{
		List<Map<String, Object>> districtna12 = template2.queryForList("select distinct districtname from govtfarms_datafeedermobapp order by districtname");
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "Agriculture/Report_Govt_Farms";
	}
	
	@GetMapping("/Report_Soil_Testing_Labs")
	public String Report_Soil_Testing_Labs(Model model, Principal principal)
	{
		List<Map<String, Object>> districtna12 = template2.queryForList("select distinct districtname from soiltestinglabs_datafeedermobapp order by districtname");
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "Agriculture/Report_Soil_Testing_Labs";
	}
	
	@GetMapping("/Report_Custom_Hiring_Center")
	public String Report_Custom_Hiring_Center(Model model, Principal principal)
	{
		List<Map<String, Object>> districtna12 = template2.queryForList("select distinct districtname from customhiringcenter_datafeedermobapp order by districtname");
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "Agriculture/Report_Custom_Hiring_Center";
	}
	
	@GetMapping("/Report_Integrated_Pest_Management_Labs")
	public String Report_Integrated_Pest_Management_Labs(Model model, Principal principal)
	{
		List<Map<String, Object>> districtna12 = template2.queryForList("select distinct districtname from integratedpestmanagementlabs_datafeedermobapp order by districtname");
		model.addAttribute("distinctna_new",districtna12);
		System.out.println("distinctna_new:::"+districtna12            );
		return "Agriculture/Report_Integrated_Pest_Management_Labs";
	}
	  


	//===============================
	
	
		 @GetMapping("/getdistbystate1111")
		    @ResponseBody
		    public List<Map<String, Object>> getdistbystate1111(Model model, @RequestParam("state") String divisionname) {

		        // String tempdist = "select * from district2014_bound where
		        // stcode11='"+stcode+"'";
		        String tempdist = "select distinct districtname from agriculture_mobdata_insert  where division IN ('"
		                + divisionname + "') and districtname is not null order by districtname asc";
		        List<Map<String, Object>> distbyst = template2.queryForList(tempdist);
		        return distbyst;

		    }
		@GetMapping("/gettalukabydist11")
	    @ResponseBody
	    public List<Map<String, Object>> gettalukabydist111(Model model, @RequestParam("dtcode") String districtname) {

	        // String temptaluka = "select name11, sdtcode11 from subdistrict2011_bound
	        // where dtcode11='"+dtcode+"'";
	        String temptaluka = "select distinct blockname from agriculture_mobdata_insert  where districtname='" + districtname
	                + "' and blockname is not null order by blockname asc";
	        List<Map<String, Object>> talukabydist = template2.queryForList(temptaluka);
	        return talukabydist;

	    }
		//rucha --------------------------------------------------------------------------
		 @GetMapping("/govtfarmdataedit/{id}")
			public String showdata(@PathVariable("id")String id,Model model, Principal principal)
			{
		       model.addAttribute("id",id);
				model.addAttribute("govtfarmdatafeeder",template2.queryForList("select * from govtfarms_datafeedermobapp where id='"+id+"'"));
			           
				return "Agriculture/GovtFarmDataFeederEdit";
			}
			
			@PostMapping("Savegovtfarmdatafeeder")
			@Transactional("transactionManager2")
			public String Savegovtfarmdata(@ModelAttribute("govtfarmdatafeeder") GovtFarmDataFeeder govtfarmdatafeeder,Model model, Principal principal ) {
				
				try {
				
				model.addAttribute("saveddata", govtfarmdatafeeder);
				
				GovtFarmDataFeeder finaldata=govtrepo.save(govtfarmdatafeeder);
				
				
			     }catch(Throwable th) {
			    	 System.out.println(th);
			    	 th.printStackTrace();
			    	
			     }
		         
				//return "Agriculture/modal";
				return "redirect:/Report_Govt_Farms";
			} 
			@GetMapping("/solarpumpdatafeeder/{id}")
			public String showsolardata(@PathVariable("id")String id,Model model, Principal principal)
			{
		       model.addAttribute("id",id);
				model.addAttribute("solarpumpdatafeeder",template2.queryForList("select * from solarpump_datafeedermobapp where id='"+id+"'"));
			           
				return "Agriculture/SolarPumpDataFeederEdit";
			}
			
			@PostMapping("Savesolarpumpdata")
			@Transactional("transactionManager2")
			public String Savesolarpumpdata(@ModelAttribute("solarpump") SolarPumpDataFeeder solarpump,Model model, Principal principal ) {
				
				try {
				
				model.addAttribute("savesolarpump", solarpump);
				
				SolarPumpDataFeeder finaldata1=solarrepo.save(solarpump);
				
				
			     }catch(Throwable th) {
			    	 System.out.println(th);
			    	 th.printStackTrace();
			    	
			     }
		         
				//return "Agriculture/modal";
				return "redirect:/Report_Solar_Pump";
			} 
			
			@GetMapping("/pestmanagementedit/{id}")
			public String showpestdata(@PathVariable("id")String id,Model model, Principal principal)
			{
		       model.addAttribute("id",id);
				model.addAttribute("pestmanagementdata",template2.queryForList("select * from integratedpestmanagementlabs_datafeedermobapp where id='"+id+"'"));
			           
				return "Agriculture/IntegratedPestManagementLabsEdit";
			}
			
			@PostMapping("Savepestmanagementdata")
			@Transactional("transactionManager2")
			public String Savepestdata(@ModelAttribute("Savepestmanagementdata")IntegratedPestManagementLabs pestdata ,Model model, Principal principal ) {
				
				try {
				
				model.addAttribute("savepestdata", pestdata);
				
				IntegratedPestManagementLabs finaldata2=pestrepo.save(pestdata);
				
				
			     }catch(Throwable th) {
			    	 System.out.println(th);
			    	 th.printStackTrace();
			    	
			     }
		         
				//return "Agriculture/modal";
				return "redirect:/Report_Integrated_Pest_Management_Labs";
			} 
			
		 
		 
		 
		 //ravi---------------------------------------------------------------------------------
		 @GetMapping("/universityEdit/{id}") public String uniEdit(@PathVariable("id")String id, Model model) {
				  
				  // int id = AssetsMappingform.getId(); //System.out.println("idd" + id); //
				  model.addAttribute("id", id);
				  model.addAttribute("universityreportform", template2.queryForList("select * from university_datafeedermobapp where id='"+id+"'"));
//						  reportfarmmachinbank.findById(Integer.parseInt(id)).orElse(new Report_Farm_Machinary_Bank()));
				  
				  return "Agriculture/Report_University_Edit"; }
			 
			 @PostMapping("Saveunidata")
				@Transactional("transactionManager2")
				public String Saveayushmobiledata(@ModelAttribute("Saveunidata") UniversityData str, Model model,
						Principal principal) {

					try {

						// System.out.println(tr.getDistrict());
						// System.out.println(tr.getAyush_sub_department());
						// System.out.println(tr.getOffice_type());
						// System.out.println(tr.getOffice_name());

						model.addAttribute("savedata", str);

						UniversityData finaldata = universityrepo.save(str);
						// model.addAttribute("msg", "Data updated Sucessfully");
						
					} catch (Throwable th) {
						System.out.println(th);
						th.printStackTrace();

					}
					//rd.addFlashAttribute("msag","Data updated Sucessfully");
					
					return "redirect:/Report_University";
				}

		@GetMapping("/soilTestLabEdit/{id}") public String soilTestEdit(@PathVariable("id")String id, Model model) {
				  
				  // int id = AssetsMappingform.getId(); //System.out.println("idd" + id); //
				  model.addAttribute("id", id);
				  model.addAttribute("soilTestLabreportform", template2.queryForList("select * from soiltestinglabs_datafeedermobap where id='"+id+"'"));
//						  reportfarmmachinbank.findById(Integer.parseInt(id)).orElse(new Report_Farm_Machinary_Bank()));
				  
				  return "Agriculture/Report_Soil_Testing_Labs_Edit"; }
			 
			 @PostMapping("Savesoiltestdata")
				@Transactional("transactionManager2")
				public String Savesoiltestdata(@ModelAttribute("Savesoiltestdata") SoilTestLabData ur, Model model,
						Principal principal, RedirectAttributes  rd) {

					try {

						// System.out.println(tr.getDistrict());
						// System.out.println(tr.getAyush_sub_department());
						// System.out.println(tr.getOffice_type());
						// System.out.println(tr.getOffice_name());

						model.addAttribute("savesoildata", ur);

						SoilTestLabData finaldata = soilrepo.save(ur);
						rd.addAttribute("msg", "Data updated Sucessfully");
						
					} catch (Throwable th) {
						System.out.println(th);
						th.printStackTrace();

					}
					//rd.addFlashAttribute("msag","Data updated Sucessfully");
					
					return "redirect:/Report_Soil_Testing_Labs";
				}
			
			
			
			
			
		//neha--------------------------------------------------------------------------------------------

		 @GetMapping("/FertilizerEdit/{id}") public String FertilizerEdit(@PathVariable("id")String id, Model model) {
				  
				  // int id = AssetsMappingform.getId(); //System.out.println("idd" + id); //
				  model.addAttribute("id", id);
				  model.addAttribute("fertilizerform", template2.queryForList("select * from fertilizer_datafeedermobapp where id='"+id+"'"));
			
//						  reportfarmmachinbank.findById(Integer.parseInt(id)).orElse(new Report_Farm_Machinary_Bank()));
				  
				  return "Agriculture/Report_Fertilizer_Edit";
			
			}
			
			
			 @PostMapping("Savefertilizerdata")
			 @Transactional("transactionManager2")
				public String Savefertilizerdata(@ModelAttribute("Savefertilizerdata")  FertilizerData fd,Model model, Principal principal  ) {
						
					try {
					    	 
						//System.out.println(tr.getDistrict());
					//	System.out.println(tr.getAyush_sub_department());
						//System.out.println(tr.getOffice_type());
						//System.out.println(tr.getOffice_name());
						
					model.addAttribute("savedata", fp);
					
						
					FertilizerData finaldata=fp.save(fd);
						
					 }catch(Throwable th) {
					    	System.out.println(th);
					    	th.printStackTrace();
					    	
					    }
					 	//redirAttrs.addFlashAttribute("success", "Everything went just fine.");
						return "redirect:/Report_Fertilizer";
					} 

			
			@GetMapping("/PesticidesEdit/{id}") public String PesticidesEdit(@PathVariable("id")String id, Model model) {
				  
				  // int id = AssetsMappingform.getId(); //System.out.println("idd" + id); //
				  model.addAttribute("id", id);
				  model.addAttribute("pesticideform", template2.queryForList("select * from pesticides_datafeedermobapp where id='"+id+"'"));
			
//						  reportfarmmachinbank.findById(Integer.parseInt(id)).orElse(new Report_Farm_Machinary_Bank()));
				  
				  return "Agriculture/Report_Pesticides_Edit";
			
			}
			
			
			 @PostMapping("Savepesticidesdata")
			 @Transactional("transactionManager2")
				public String Savepesticidesdata(@ModelAttribute("Savepesticidesdata")  PesticidesData pd,Model model, Principal principal  ) {
						
					try {
					    	 
						//System.out.println(tr.getDistrict());
					//	System.out.println(tr.getAyush_sub_department());
						//System.out.println(tr.getOffice_type());
						//System.out.println(tr.getOffice_name());
						
					model.addAttribute("savepestdata", pp);
					
						
					PesticidesData finalpdata=pp.save(pd);
						
					 }catch(Throwable th) {
					    	System.out.println(th);
					    	th.printStackTrace();
					    	
					    }
					 	//redirAttrs.addFlashAttribute("success", "Everything went just fine.");
						return "redirect:/Report_Pesticides";
					} 

			 
			
			//ashvini-----------------------------------------------------------------------
			@GetMapping("/FarmmachinaryBankEdit/{id}")
			public String edit(@PathVariable("id") String id, Model model) {

				// int id = AssetsMappingform.getId(); //System.out.println("idd" + id); //
				model.addAttribute("id", id);
				model.addAttribute("farmmachinarybankform",
						template2.queryForList("select * from farmmachienerybank_datafeedermobapp where id='" + id + "'"));
//					  reportfarmmachinbank.findById(Integer.parseInt(id)).orElse(new Report_Farm_Machinary_Bank()));

				return "Agriculture/Report_Farm_Machinary_Bank_Edit";
			}

			@PostMapping("Updatedata2023")
			@Transactional("transactionManager2")
			public String Savefarmmachinarybank(@ModelAttribute("Updatedata2023") Report_Farm_Machinary_Bank rfb, Model model,
					Principal principal) {

				try {

					model.addAttribute("farmmachinarybankform", rfb);

					Report_Farm_Machinary_Bank finaldata = reportfarmmachinbank.save(rfb);
					model.addAttribute("msg", "Data Updated Successfully..!!");
				} catch (Throwable th) {
					System.out.println(th);
					th.printStackTrace();

				}

				return "redirect:/Report_Farm_Machinary_Bankrpt";
			}

			@GetMapping("/KrishivkendraEdit/{id}")
			public String editkrishiv(@PathVariable("id") String id, Model model) {

				// int id = AssetsMappingform.getId(); //System.out.println("idd" + id); //
				model.addAttribute("id", id);
				model.addAttribute("krishivkendra",
						template2.queryForList("select * from krishivigyankendra_datafeedermobapp where id='" + id + "'"));
//					  reportfarmmachinbank.findById(Integer.parseInt(id)).orElse(new Report_Farm_Machinary_Bank()));

				return "Agriculture/Report_Krishi_Vigyan_Kendra_Edit";
			}

			@PostMapping("Updatekrishivgyan")
			@Transactional("transactionManager2")
			public String Savekrishivgyankendra(@ModelAttribute("Updatekrishivgyan") krishivigyankendra kgk, Model model,
					Principal principal) {

				try {

					model.addAttribute("krishivkendra", kgk);

					krishivigyankendra finaldata = krishivrepo.save(kgk);

				} catch (Throwable th) {
					System.out.println(th);
					th.printStackTrace();

				}

				return "redirect:/Report_Krishi_Vigyan_Kendra";
			}

			

			@GetMapping("/CustomHiringEdit/{id}")
			public String editcustomhiring(@PathVariable("id") String id, Model model) {

				// int id = AssetsMappingform.getId(); //System.out.println("idd" + id); //
				model.addAttribute("id", id);
				model.addAttribute("customhiring",
						template2.queryForList("select * from customhiringcenter_datafeedermobapp where id='" + id + "'"));
//					  reportfarmmachinbank.findById(Integer.parseInt(id)).orElse(new Report_Farm_Machinary_Bank()));

				return "Agriculture/Report_Custom_Hiring_Edit";
			}

			@PostMapping("Updatecustomhiring")
			@Transactional("transactionManager2")
			public String Savecustomhiring(@ModelAttribute("Updatecustomhiring") Customhiringcenter crc, Model model,
					Principal principal) {

				try {

					model.addAttribute("customhiring", crc);

					Customhiringcenter finaldata = customhirerepo.save(crc);

				} catch (Throwable th) {
					System.out.println(th);
					th.printStackTrace();

				}

				return "redirect:/Report_Custom_Hiring_Center";
			}

		//khushnuma------------------------------------------------------------------------------------------------------
			
			 
			    @PostMapping("/Update_Khet_Talaab")
				  public String  Update_Khet_Talaab(String id ,String districtname)
				  {
					 try {

						  System.out.println(districtname +"="+id);
						  return"redirect:/Report_Khet_Talaab";
					} catch (Exception e) {
						// TODO: handle exception
						e.printStackTrace();
						return "fdesf";
					}
					  }
			    
				   @GetMapping("/Report_Khet_Talaab_Edit/{id}") 
				  public String Report_Khet_Talaab_Edit(@PathVariable("id")String id, Model model) {
					  //System.out.println("seerefe>>>>");
					  // int id = AssetsMappingform.getId(); //System.out.println("idd" + id); //
					  model.addAttribute("id", id);
					  model.addAttribute("ReportKhettalabform", template2.queryForList("select * from khettalaab_datafeedermobapp where id='"+id+"'"));
//							  reportfarmmachinbank.findById(Integer.parseInt(id)).orElse(new Report_Farm_Machinary_Bank()));
					  
					  return "Agriculture/Report_Khet_Talaab_Edit";}
			    
				   @PostMapping("savetalab")
					@Transactional("transactionManager2")
					public String Saveayushmobiledata(@ModelAttribute("savetalab") KhetTalaabDataFeeder kt,Model model, Principal principal  ) {
					   
						try {
					    	 
						//System.out.println(tr.getDistrict());
					//	System.out.println(tr.getAyush_sub_department());
						//System.out.println(tr.getOffice_type());
						//System.out.println(tr.getOffice_name());
						
						model.addAttribute("khettalaabreport", kt);
						
						KhetTalaabDataFeeder finaldata=ktrepo.save(kt);
						
					     }catch(Throwable th) {
					    	 System.out.println(th);
					    	 th.printStackTrace();
					    	
					     }
						return "redirect:/Report_Khet_Talaab";
										
				   }
				   
				   
				   @GetMapping("/Report_Seed_Edit/{id}") 
				public String Report_Seed_Edit(@PathVariable("id")String id, Model model) {
					  //System.out.println("seerefe>>>>");
					  // int id = AssetsMappingform.getId(); //System.out.println("idd" + id); //
					  model.addAttribute("id", id);
					  model.addAttribute("ReportSeedform", template2.queryForList("select * from seed_datafeedermobapp where id='"+id+"'"));
//							  reportfarmmachinbank.findById(Integer.parseInt(id)).orElse(new Report_Farm_Machinary_Bank()));
					  
					  return "Agriculture/Report_Seed_Edit";}

				 @PostMapping("saveseed")
					@Transactional("transactionManager2")
					public String Saveayushmobiledata(@ModelAttribute("saveseed") SeedDataFeeder sr,Model model, Principal principal  ) {
					   
						try {
					    	 
						//System.out.println(tr.getDistrict());
					//	System.out.println(tr.getAyush_sub_department());
						//System.out.println(tr.getOffice_type());
						//System.out.println(tr.getOffice_name());
						
						model.addAttribute("ReportSeedform", sr);
						
						SeedDataFeeder finaldata = srrepo.save(sr);
						
					     }catch(Throwable th) {
					    	 System.out.println(th);
					    	 th.printStackTrace();
					    	
					     }
						return "redirect:/Report_Seed";
										
				 }

	   
////////////////////UPPCL Energy Pole reports And UPDATE
					
					
		@GetMapping("/Uppcl_Pole_Report")
		public String Uppcl_pole(Model model, Principal principal)
		{
			//List<Map<String, Object>> districtna12 = Template2.queryForList("select distinct circle from feederline_sarvey_uppclmobapp order by circle");
			List<Map<String, Object>> districtna12 = template2.queryForList("select distinct circle from feederline_sarvey_uppclmobapp order by circle");
			model.addAttribute("distinctna_new",districtna12);
			System.out.println("distinctna_new:::"+districtna12            );
			return "Agriculture/Uppcl_Pole_Report";
		}
		@GetMapping("/UppclPoleEdit/{id}")
		public String UppclPoleEdit(@PathVariable("id") String id, Model model) {

			// int id = AssetsMappingform.getId(); //System.out.println("idd" + id); //
			model.addAttribute("id", id);
			model.addAttribute("uppclpoledata",
		    template2.queryForList("select * from feederline_sarvey_uppclmobapp where id='" + id + "'"));
//				

			return "Agriculture/Uppcl_Pole_Edit";
		}

		@PostMapping("UpdateUppclpoledata")
		@Transactional("transactionManager2")
		public String UpdateUppclpoledata(@ModelAttribute("UpdateUppclpoledata") UppclPole_Energy crc, Model model,
				Principal principal) {

			try {

				model.addAttribute("uppclpoledata", crc);

				UppclPole_Energy finaldata = uppclpolerepo.save(crc);

			} catch (Throwable th) {
				System.out.println(th);
				th.printStackTrace();

			}

			return "redirect:/Uppcl_Pole_Report";
		}
		
		
		 @RequestMapping(value = "Uppcldelete/{id}", method = RequestMethod.GET)		  
		  @Transactional("transactionManager2") 
		  public String Uppcldelete(@PathVariable("id") int id) { 
			 uppclpolerepo.deleteById(id);
		  return "redirect:/Uppcl_Pole_Report"; 
		  }
		 
		 //////////////UPPCL CHARTS//////////////////////////////////////
		 
		 @GetMapping("/uppclcharts")	
		 public String showchart(Model model)
		 {
			    UppclPole_Energy upen = new UppclPole_Energy();
				model.addAttribute("upen", upen);
				
				List<Map<String, Object>>  listofcircle = template2.queryForList("select distinct circle from feederline_sarvey_uppclmobapp order by circle");
				 List<Object> list=new ArrayList<Object>();
			      for(Map<String,Object> i:listofcircle){
			          list.addAll(i.values());
			      }
				model.addAttribute("listofcircle",list);
				model.addAttribute("upens", uppclpolerepo.findAll());
				return "Agriculture/UppclChart";
					 
		 }
		 
		 @GetMapping("/uppclchartdata")
		 @ResponseBody
		 public List<Map<String,Object>> showchartdata(Model model,HttpServletRequest req,HttpServletResponse res) throws IOException
			{ /*
				 * List<String> keyValues=null; List<Object> valValues=null;
				 */
			 UppclPole_Energy upenn = new UppclPole_Energy();
				model.addAttribute("upenn", upenn);
				
			 List<Map<String,Object>> data = uppclpolerepo.getlistofcircle();
			 model.addAttribute("upenns", data);
				/*
				 * Iterator<Map<String, Object>> it = data.iterator();
				 * 
				 * // Loop through a collection while(it.hasNext()) {
				 * 
				 * for (Map.Entry<String,Object> entry : it.next().entrySet()) {
				 * System.out.println("Key = " + entry.getKey()+ ", Value = " +
				 * entry.getValue()); keyValues.add(entry.getKey());
				 * valValues.add(entry.getValue()); }
				 * 
				 * }
				 */

			 return data;
		 }
		/////////UPPCL UPDATE END


	    // imran CODE Dashboard
	    @RequestMapping("/agridashboard")
	    public String cgmdashboard(Model model) {

	        //try {
	            String querystate = "select distinct division from agriculture_mobdata_insert where division is NOT NULL order by division asc";
	            List<Map<String, Object>> statename = template2.queryForList(querystate);
	            model.addAttribute("statename", statename);

				
				  String tempdept = "select count(*) from  farmmachienerybank_datafeedermobapp";
				  model.addAttribute("totalarea", template2.queryForList(tempdept)); 
				  String tempdept1 = "select count(*) from  fertilizer_datafeedermobapp";
				  model.addAttribute("totalareaongc", template2.queryForList(tempdept1));
				  String tempdept2 = "select count(*) from  seed_datafeedermobapp";
				  model.addAttribute("totalareadsf_iii", template2.queryForList(tempdept2));
				  String tempdept4 = "select count(*) from  pesticides_datafeedermobapp";
				  model.addAttribute("totalaredata1", template2.queryForList(tempdept4));
				  String tempdept5 = "select count(*) from  khettalaab_datafeedermobapp";
				  model.addAttribute("totalaredata2", template2.queryForList(tempdept5));
				  String tempdept6 = "select count(*) from   solarpump_datafeedermobapp";
				  model.addAttribute("totalaredata3", template2.queryForList(tempdept6));
				  String tempdept7 = "select count(*) from   university_datafeedermobapp";
				  model.addAttribute("totalaredata4", template2.queryForList(tempdept7));
				  String tempdept8 =
				  "select count(*) from  krishivigyankendra_datafeedermobapp";
				  model.addAttribute("totalaredata5", template2.queryForList(tempdept8));
				  String tempdept9 = "select count(*) from  govtfarms_datafeedermobapp";
				  model.addAttribute("totalaredata6", template2.queryForList(tempdept9));
				  String tempdept10 = "select count(*) from  soiltestinglabs_datafeedermobapp";
				  model.addAttribute("totalaredata7", template2.queryForList(tempdept10));
				  String tempdept11 =
				  "select count(*) from  customhiringcenter_datafeedermobapp";
				  model.addAttribute("totalaredata8", template2.queryForList(tempdept11));
				  String tempdept12 =
				  "select count(*) from  integratedpestmanagementlabs_datafeedermobapp";
				  model.addAttribute("totalaredata9", template2.queryForList(tempdept12));
				 
	            return "Agriculture/Agriculture_dashboard";

	       /* } catch (Exception e) {
	            // TODO: handle exception
	            e.printStackTrace();
	            return "redirect:/admin";
	        }
	*/
	    }

	    @GetMapping("/getseletedstate")
	    @ResponseBody
	    public List<List<Map<String, Object>>> getseletedstate(Model model,@RequestParam("State")String division,@RequestParam("District")String districtname,
	            @RequestParam("Taluka")String blockname,@RequestParam("Village")String villcode,String data) {
	        
	        System.out.println(division +"---------"+ districtname +"-----"+ blockname);
	        
	         String tempdist = "select count(*) from  farmmachienerybank_datafeedermobapp  where " ; 
	         String tempdist1 = "select count(*) from  fertilizer_datafeedermobapp  where " ;
	         String tempdist2 = "select count(*) from  seed_datafeedermobapp  where ";
	         String tempdist4 = "select count(*) from  pesticides_datafeedermobapp  where " ; 
	         String tempdist5 = "select count(*) from  khettalaab_datafeedermobapp  where " ;
	         String tempdist6 = "select count(*) from  solarpump_datafeedermobapp  where ";
	        // String tempdist7 = "select count(*) from  university_datafeedermobapp  where " ;
	         //String tempdist8 = "select count(*) from  krishivigyankendra_datafeedermobapp  where " ; 
	         String tempdist9 = "select count(*) from  govtfarms_datafeedermobapp  where " ;
	         String tempdist10 = "select count(*) from  soiltestinglabs_datafeedermobapp  where ";
	         String tempdist12 = "select count(*) from  customhiringcenter_datafeedermobapp  where " ; 
	         String tempdist13 = "select count(*) from  integratedpestmanagementlabs_datafeedermobapp  where " ;
	         
	        
	            
	                if(!division.equals("0")) {
	                  tempdist+= "division IN ('"+division+"') and ";
	                  tempdist1+= "division IN ('"+division+"') and ";
	                  tempdist2+= "division IN ('"+division+"') and ";
	                  tempdist4+= "division IN ('"+division+"') and "; 
	                  tempdist5+="division IN ('"+division+"') and "; 
	                  tempdist6+= "division IN ('"+division+"') and ";
	                  //tempdist7+= "division IN ('"+division+"') and ";
	                  //tempdist8+= "division IN ('"+division+"') and "; 
	                  tempdist9+="division IN ('"+division+"') and "; 
	                  tempdist10+= "division IN ('"+division+"') and ";
	                  tempdist12+= "division IN ('"+division+"') and "; 
	                  tempdist13+="division IN ('"+division+"') and "; 
	                
	                 
	                
	                     }
	         if(!districtname.equals("0")) {
	             tempdist+= "districtname IN ('"+districtname+"') and ";
	             tempdist1+= "districtname IN ('"+districtname+"') and ";
	             tempdist2+= "districtname IN ('"+districtname+"') and ";            
	             tempdist4+= "districtname IN ('"+districtname+"') and "; 
	              tempdist5+="districtname IN ('"+districtname+"') and "; 
	              tempdist6+= "districtname IN ('"+districtname+"') and ";
	             // tempdist7+= "districtname IN ('"+districtname+"') and ";
	             // tempdist8+= "districtname IN ('"+districtname+"') and "; 
	              tempdist9+="districtname IN ('"+districtname+"') and "; 
	              tempdist10+= "districtname IN ('"+districtname+"') and ";
	              tempdist12+= "districtname IN ('"+districtname+"') and "; 
	              tempdist13+="districtname IN ('"+districtname+"') and "; 
	             
	             
	             
	            
	         }
	         if(!blockname.equals("0")) {
	             tempdist+= "blockname IN ('"+blockname+"') and ";
	             tempdist1+= "blockname IN ('"+blockname+"') and ";
	             tempdist2+= "blockname IN ('"+blockname+"') and ";  
	               tempdist4+= "blockname IN ('"+blockname+"') and ";
	                  tempdist5+="blockname IN ('"+blockname+"') and "; tempdist6+=
	                  "blockname IN ('"+blockname+"') and "; 
	                 // tempdist7+="blockname IN ('"+blockname+"') and "; 
	                 // tempdist8+="blockname IN ('"+blockname+"') and ";
	                  tempdist9+="blockname IN ('"+blockname+"') and "; 
	                  tempdist10+="blockname IN ('" + blockname + "') and ";
	                    tempdist12+=
	                  "blockname IN ('"+blockname+"') and ";
	                  tempdist13+="blockname IN ('"+blockname+"') and "; 
	                  
	                  
	                 
	         }
	       
	         if(!villcode.equals("0")) {
	             tempdist+= "villcode IN ('"+villcode+"') and ";
	             tempdist1+= "villcode IN ('"+villcode+"') and ";
	             tempdist2+= "villcode IN ('"+villcode+"') and ";
//	             tempdist3+= "villcode IN ('"+villcode+"') and ";
	                
	                  tempdist4+= "villcode IN ('"+villcode+"') and ";
	                  tempdist5+="villcode IN ('"+villcode+"') and "; tempdist6+=
	                  "villcode IN ('"+villcode+"') and ";
	               //   tempdist7+="villcode IN ('"+villcode+"') and "; 
	               //   tempdist8+="villcode IN ('"+villcode+"') and ";
	                  tempdist9+="villcode IN ('"+villcode+"') and "; tempdist10+=
	                            "villcode IN ('" + villcode + "') and ";
	                    /*
	                     * tempdist11+= "sdtcode IN ('"+sdtcode+"') and ";
	                     */ tempdist12+=
	                  "villcode IN ('"+villcode+"') and ";
	                  tempdist13+="villcode IN ('"+villcode+"') and "; 
	                  
	                 
	         }
	        
	         tempdist = tempdist.substring(0, tempdist.length() - 4);
	         System.out.println("tempdist2"+tempdist2);
	         tempdist1 = tempdist1.substring(0, tempdist1.length() - 4);
	         tempdist2 = tempdist2.substring(0, tempdist2.length() - 4);
//	         tempdist3 = tempdist3.substring(0, tempdist3.length() - 4);
	            
	              tempdist4 = tempdist4.substring(0, tempdist4.length() - 4); 
	              tempdist5 =
	              tempdist5.substring(0, tempdist5.length() - 4); 
	              tempdist6 =
	              tempdist6.substring(0, tempdist6.length() - 4); 
	             // tempdist7 =
	             // tempdist7.substring(0, tempdist7.length() - 4); 
	             // tempdist8 =
	              //tempdist8.substring(0, tempdist8.length() - 4); 
	              tempdist9 =
	              tempdist9.substring(0, tempdist9.length() - 4);
	              tempdist10 =
	              tempdist10.substring(0, tempdist10.length() - 4);
	                /*
	                 * tempdist11 = tempdist11.substring(0, tempdist12.length() - 4);
	                 */
	              tempdist12 =
	              tempdist12.substring(0, tempdist12.length() - 4); 
	              tempdist13 =
	              tempdist13.substring(0, tempdist13.length() - 4); 
	             
	         
	        
	         List<Map<String, Object>> distbyst = template2.queryForList(tempdist);  
	         List<Map<String, Object>> distbyst1 = template2.queryForList(tempdist1);
	         List<Map<String, Object>> distbyst2 = template2.queryForList(tempdist2);  
//	         List<Map<String, Object>> distbyst3 = template3.queryForList(tempdist3);
	            
	              List<Map<String, Object>> distbyst4 = template2.queryForList(tempdist4);
	              List<Map<String, Object>> distbyst5 = template2.queryForList(tempdist5);
	              List<Map<String, Object>> distbyst6 = template2.queryForList(tempdist6);
	             // List<Map<String, Object>> distbyst7 = template2.queryForList(tempdist7);
	             // List<Map<String, Object>> distbyst8 = template2.queryForList(tempdist8);
	              List<Map<String, Object>> distbyst9 = template2.queryForList(tempdist9);
	              List<Map<String, Object>> distbyst10 = template2.queryForList(tempdist10);
	             // List<Map<String, Object>> distbyst11 = templet.queryForList(tempdist11);
	              List<Map<String, Object>> distbyst12 = template2.queryForList(tempdist12);
	              List<Map<String, Object>> distbyst13 = template2.queryForList(tempdist13);
	              
	             
	         
	         List<List<Map<String, Object>>> templistoflist = new ArrayList<>();
	        
	         
	         templistoflist.add(distbyst);
	         templistoflist.add(distbyst1);
	         templistoflist.add(distbyst2);
//	         templistoflist.add(distbyst3);
	        
	              templistoflist.add(distbyst4); 
	              templistoflist.add(distbyst5);
	              templistoflist.add(distbyst6); 
	              //templistoflist.add(distbyst7);
	              //templistoflist.add(distbyst8); 
	              templistoflist.add(distbyst9);
	              templistoflist.add(distbyst10);
	              //templistoflist.add(distbyst11);
	              templistoflist.add(distbyst12); 
	              templistoflist.add(distbyst13);
	         //     System.out.println("templistoflist"+templistoflist);
	             
	         
	         
	         
	        return templistoflist;
	    }
}
